#autor: Imenko Prezimić INDEX ra1234-2015
.section .data
    input_msg: .ascii "Unesite string: \0"
    input_duzina = . - input_msg
    output_msg: .ascii "Izlaz: \0"
    output_duzina = . - output_msg
    max_len = 30
    ulazni_string: .fill max_len,1,42
    izlazni_string: .fill max_len,1,42
    izlazni_duzina: .long 0
.section .text
.global main
main:
        movl $4,%eax
        movl $1,%ebx
        movl $input_msg,%ecx
        movl $input_duzina,%edx
        int $0x80

        movl $3,%eax
        movl $0,%ebx
        movl $ulazni_string,%ecx
        movl $max_len,%edx
        int $0x80

        movl $ulazni_string,%eax
        movl $izlazni_string,%ebx

        #pozicija u ulaznom stringu
        movl $0,%esi
        #pozicija na izlaznom stringu
        movl $0,%edi

petlja:
        movb (%eax,%esi,1),%cl

        cmpb $10,%cl
        je kraj
        cmpb $105,%cl
        je obrnipriprema

        movb %cl,(%ebx,%edi,1)

        addl $1,%esi
        addl $1,%edi

        jmp petlja

obrnipriprema:
        movl %edi,izlazni_duzina
        movl $0,%edx
        subl $1,%edi
        addl $1,%esi
obrni:
        cmpl %edx,%edi
        jbe obrnikraj

        movb (%ebx,%edx,1),%cl
        movb (%ebx,%edi,1),%ch
        
        movb %ch,(%ebx,%edx,1)
        movb %cl,(%ebx,%edi,1)

        subl $1,%edi
        addl $1,%edx
        jmp obrni
obrnikraj:
        movl izlazni_duzina,%edi
        jmp petlja
kraj:
        movl %edi,izlazni_duzina

        movl $4,%eax
        movl $1,%ebx
        movl $output_msg,%ecx
        movl $output_duzina,%edx
        int $0x80

        movl $4,%eax
        movl $1,%ebx
        movl $izlazni_string,%ecx
        movl izlazni_duzina,%edx
        int $0x80

        movl $1,%eax
        movl $0,%ebx
        int $0x80
