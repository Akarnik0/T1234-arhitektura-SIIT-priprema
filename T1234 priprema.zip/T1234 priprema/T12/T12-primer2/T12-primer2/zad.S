#autor: Imenko Prezimić INDEX pr1234-2022

.section .data
ulaz_str: .ascii "Unesite string: \0"
ulaz_duzina = . - ulaz_str
max_ulaz = 50
string: .fill max_ulaz,1,42
uzastopni: .long 0
.section .text
.global main
main:
        movl $4,%eax
        movl $1,%ebx
        movl $ulaz_str,%ecx
        movl $ulaz_duzina,%edx
        int $0x80

        movl $3,%eax
        movl $0,%ebx
        movl $string,%ecx
        movl $max_ulaz,%edx
        int $0x80
        
        #pointer na string
        movl $string,%eax

        #brojac karaktera stringa
        movl $0,%edi

        #bool IsLastCharLower
        movl $0,%esi

        #brojac 2 uzastopna mala slova
        movl $0,%ebx
petlja:
        #trenutni karakter stringa u %cl
        movb (%eax,%edi,1),%cl

        cmpb $10,%cl
        je kraj

        cmpb $97,%cl
        jae provjera2

        movl $0,%esi

        jmp inkrement
provjera2:
        cmpb $122,%cl
        jbe setbool

        movl $0,%esi

        jmp inkrement
setbool:
        cmpl $1,%esi
        je povecajbrojac
        movl $1,%esi
        jmp inkrement
povecajbrojac:
        addl $1,%ebx
        movl $0,%esi
        jmp inkrement
inkrement:
        addl $1,%edi
        jmp petlja
kraj:
        movl $1,%eax
        int $0x80
