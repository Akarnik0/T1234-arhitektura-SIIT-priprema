# autor: Imenko Prezimić INDEX ra1234-2018
# unsigned int setOnes(unsigned int numOnes, unsigned int start)
.section .data
.section .text
.global setOnes
setOnes:
        pushl %ebp
        movl %esp,%ebp
        pushl %ebx
        #izgled stack-a:
        #12(%ebp) - unsigned int start
        #8(%ebp) - unsigned int numOnes
        #4(%ebp) - povratna adresa
        #0(%ebp) - stari ebp
        #4(%ebp) - stari ebx
        #8(%ebp) - binarni niz sa lijeve strane ka desno

        #broj jedinica u eax
        movl 8(%ebp),%eax
        #startna pozicija u ecx
        movl 12(%ebp),%ecx
        #rezultujuci binarni niz u edx
        movl $0,%edx
        #brojac
        movl $0,%ebx
petlja:
        #ako su unesene sve jedinice pomjeri binarni niz desno
        cmpl %eax,%ebx
        je pomjeridesno
        
        #dodavanje jedinica u binarni niz
        orl $1,%edx
        rorl $1,%edx

        #inkrement brojaca
        addl $1,%ebx

        jmp petlja
pomjeridesno:
        #resetovanje brojaca
        movl $0,%ebx

        #pomjeranje desno
        rorl %cl,%edx

        #stavljanje prvog binarnog niza u stack
        pushl %edx

        #resetovanje %edx
        movl $0,%edx

        jmp petlja1
petlja1:
        cmpl %eax,%ebx
        je kraj
        
        orl $1,%edx
        roll $1,%edx

        addl $1,%ebx

        jmp petlja1
kraj:
        subb $1,%cl
        roll %cl,%edx

        #namjestanje return value
        popl %ebx
        orl %ebx,%edx
        movl %edx,%eax
        
        popl %ebx
        popl %ebp
        ret
