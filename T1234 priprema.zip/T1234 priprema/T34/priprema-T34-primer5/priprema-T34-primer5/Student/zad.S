# Autor: IMENKO PREZIMENKOVIC
# int countSafeTracks(unsigned int *tracks, unsigned int n, unsigned int k, unsigned int minBlocks);
.section .data
.section .text
.global countSafeTracks
countSafeTracks:
        pushl %ebp
        movl %esp,%ebp
        #izgled stacka-a:
        #20(%ebp) - unsigned int minBlocks najmanji broj jedinica koje vaze u stazi
        #16(%ebp) - unsigned int k najmanji broj uzastopnih jedinica da se platforma racuna
        #12(%ebp) - unsigned int n broj staza
        #8(%ebp) - pokazivac na niz int tracks
        #4(%ebp) - povratna adresa
        #0(%ebp) -stari ebp
        #-4(%ebp) - stari ebx
        #-8(%ebp) - stari esi
        #-12(%ebp) - stari edi
        #-16(%ebp) - broj trenutne staze
        
        #prebacivanje starih vrijednosti registara
        pushl %ebx
        pushl %esi
        pushl %edi
        pushl $0

        #prebacivanje prve staze u eax
        movl 8(%ebp),%ecx
        movl (%ecx),%eax

        #brojac za iteraciju kroz staze
        movl $0,%edx

        #brojaci za trenutni niz jedinica i za ukupan broj vazecih jedinica
        movl $0,%esi
        movl $0,%edi

        #broj vazecih staza
        movl $0,%ebx
petlja:
        #ako je iterisano kroz citavu stazu prelazak na sljedecu
        cmpl $32,%edx
        je sljedecastazapriprema

        #ako je trenutni bit jedinica
        testl $1,%eax
        jnz inkrementtrenutni

        #ako nije, gledamo da li je trenutni niz jedinica dovoljno velik da ga upisemo u ukupan broj vazecih
        cmpl 16(%ebp),%esi
        jae inkrementukupan

        #resetovanje trenutnog niza ako trenutni bit nije 1
        movl $0,%esi

        addl $1,%edx
        shrl $1,%eax
        jmp petlja
sljedecastazapriprema:
        cmpl 16(%ebp),%esi
        jae inkrementukupan2
sljedecastazapriprema2:
        cmpl 20(%ebp),%edi
        jae inkrementbrojstaza
sljedecastazapriprema3:
        #broj trenutne staze u edx
        movl -16(%ebp),%edx

        #ako smo zavrsili sve staze
        cmpl %edx,12(%ebp)
        je kraj
        
        #inkrementiraj trenutni broj staze
        addl $1,%edx
        movl %edx,-16(%ebp)

        #resetuj edx
        movl $0,%edx

        movl $0,%esi
        movl $0,%edi

        #pokazivac na sledecu stazu
        addl $4,%ecx
        #prebacivanje staze u eax
        movl (%ecx),%eax

        jmp petlja
inkrementbrojstaza:
        addl $1,%ebx

        jmp sljedecastazapriprema3
inkrementukupan2:
        addl %esi,%edi
        movl $0,%esi

        jmp sljedecastazapriprema2
inkrementtrenutni:
        addl $1,%esi
        
        addl $1,%edx
        shrl $1,%eax

        jmp petlja
inkrementukupan:
        addl %esi,%edi
        movl $0,%esi

        addl $1,%edx
        shrl $1,%eax

        jmp petlja
kraj:
        movl %ebx,%eax
        popl %ebx
        popl %edi
        popl %esi
        popl %ebx
        popl %ebp
        ret
