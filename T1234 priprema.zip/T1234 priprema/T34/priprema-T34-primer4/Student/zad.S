# autor: Imenko Prezimić INDEX ra1234-2023
# unsigned long long postavi_jedinice(unsigned long long *vrednost)
.section .data
.section .text
.global postavi_jedinice
postavi_jedinice:
        pushl %ebp
        movl %esp,%ebp
        pushl %ebx
        #izgled stack-a:
        #8(%ebp) - adresa long long vrednost
        #4(%ebp) - povratna vrijednost
        #0(%ebp) - stari ebp
        #-4(%ebp) - stari ebx

        #prebacivanje nize vrijednosti long long vrednost u eax
        movl 8(%ebp),%ecx
        movl (%ecx),%eax

        #brojac
        movl $0,%edx

        #brojac nula
        movl $0,%ebx
petlja:
        cmpl $32,%edx
        je petlja2priprema

        testl $1,%eax
        jz inkrement

        addl $1,%edx
        shr $1,%eax

        jmp petlja
inkrement:
        addl $1,%ebx

        addl $1,%edx
        shr $1,%eax

        jmp petlja
petlja2priprema:
        movl $0,%edx

        movl 8(%ebp),%ecx
        movl 4(%ecx),%eax
        jmp petlja2
petlja2:
        cmpl $32,%edx
        je petlja2izlaz

        testl $1,%eax
        jz inkrement2

        addl $1,%edx
        shr $1,%eax

        jmp petlja2
inkrement2:
        addl $1,%ebx
        
        addl $1,%edx
        shr $1,%eax

        jmp petlja2
petlja2izlaz:
        movl $0,%edx
        movl $0,%eax

        jmp krajpriprema
krajpriprema:
        cmpl %ebx,%edx
        je kraj
        orl $1,%eax
        rol $1,%eax
        addl $1,%edx
        jmp krajpriprema
kraj:
        ror $1,%eax

        movl %eax,%edx
        popl %ebx
        popl %ebp
        ret
