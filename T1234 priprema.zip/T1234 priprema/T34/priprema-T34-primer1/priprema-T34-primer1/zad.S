# autor: Imenko Prezimić INDEX ra1234-2023
# int prebrojNajviseUzastopnih(unsigned long long* vrednost)
.section .data
.section .text
.global prebrojNajviseUzastopnih
prebrojNajviseUzastopnih:
        pushl %ebp
        movl %esp,%ebp
        #izgled stack-a
        #8(%ebp) - adresa vrednosti
        #4(%ebp) - povratna adresa
        #0(%ebp) - stari ebp
        #-4(%ebp) - nizih 32 bita
        #-8(%ebp) - visih 32 bita
        #-12(%ebp) - trenutni niz nula
        #-16(%ebp) - najveci niz nula
        movl 8(%ebp),%eax
        pushl (%eax)
        addl $4,%eax
        pushl (%eax)

        #poredjenje nizih 32 bita
        movl -4(%ebp),%eax
        
        #brojac broja obrtaja bita
        movl $0,%ecx

        #trenutni i najveci niz nula
        pushl $0
        pushl $0
poredjenje:
        cmpl $32,%ecx
        je visiporedjenjepriprema

        testl $1,%eax
        jz inkrement

        #0 u trenutni niz nula ako trenutni karakter nije nula
        movl $0,%edx
        movl %edx,-12(%ebp)

        #inkrement %ecx i shiftovanje u desno za 1
        addl $1,%ecx
        shr %eax
        jmp poredjenje
inkrement:
        movl -12(%ebp),%edx
        addl $1,%edx

        #ako -12(%ebp) veci od -16(%ebp) prebaci -12(%ebp) u -16(%ebp)
        cmpl %edx,-16(%ebp)
        jb inkrementnajveci

        movl %edx,-12(%ebp)

        addl $1,%ecx
        shr %eax
        jmp poredjenje
inkrementnajveci:
        movl %edx,-16(%ebp)

        movl %edx,-12(%ebp)

        addl $1,%ecx
        shr %eax
        jmp poredjenje
visiporedjenjepriprema:
        movl $0,%ecx
        movl -8(%ebp),%eax
        jmp visiporedjenje
visiporedjenje:
        cmpl $32,%ecx
        je kraj

        testl $1,%eax
        jz inkrement1

        movl $0,%edx
        movl %edx,-12(%ebp)

        addl $1,%ecx
        shr %eax
        jmp visiporedjenje
inkrement1:
        movl -12(%ebp),%edx
        addl $1,%edx

        cmpl %edx,-16(%ebp)
        jb inkrementnajveci1

        movl %edx,-12(%ebp)

        addl $1,%ecx
        shr %eax
        jmp visiporedjenje
inkrementnajveci1:
        movl %edx,-16(%ebp)

        movl %edx,-12(%ebp)

        addl $1,%ecx
        shr %eax
        jmp visiporedjenje
kraj:
        movl -16(%ebp),%eax
        addl $16,%esp
        popl %ebp
        ret
