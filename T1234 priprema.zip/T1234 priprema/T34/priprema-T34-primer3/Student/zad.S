# autor: Imenko Prezimić INDEX ra1234-2023
# void oduzmi_niz(long long *a, long *b, long long *r, int n)
.section .data
.section .text
.global oduzmi_niz
oduzmi_niz:
        pushl %ebp
        movl %esp,%ebp
        #izgled stack-a:
        #20(%ebp) - int n
        #16(%ebp) - pokazivac na r
        #12(%ebp) - pokazivac na b
        #8(%ebp) - pokazivac na a
        #4(%ebp) - povratna adresa
        #0(%ebp) - stara vrijednost ebp
        #-4(%ebp) - niza vrijednost a
        #-8(%ebp) - visa vrijednost a
        #-12(%ebp) - niza vrijednost b
        #-16(%ebp) - visa vrijednost b
        #-20(%ebp) - stari ebx
        #-24(%esi) - stari esi

        #prebacivanje prve vrijednosti long long a u stack
        movl 8(%ebp),%eax
        pushl (%eax)
        addl $4,%eax
        pushl (%eax)

        #prebacivanje prve vrijednosti long long b u stack
        movl 12(%ebp),%eax
        pushl (%eax)
        addl $4,%eax
        pushl (%eax)

        #stara vrijednost ebx i esi
        pushl %ebx
        pushl %esi

        #brojac
        movl $0,%ebx

        #n
        movl 20(%ebp),%esi

        #pokazivac na r
        movl 16(%ebp),%edx
        
        #prebacivanje visih vrijednosti a i b u registre
        movl -8(%ebp),%eax
        movl -16(%ebp),%ecx
relacijavisi:
        cmpl %esi,%ebx
        je kraj

        #ako je a veci od b
        cmpl %ecx,%eax
        jg oduzmi_a_veci

        #ako je a manji od b
        cmpl %ecx,%eax
        jl oduzmi_a_manji

        #ako su vise vrijednosti jednake
        cmpl %ecx,%eax
        je relacijamanji
relacijamanji:
        #prebacivanje nizih vrijednosti a i b u registre
        movl -4(%ebp),%eax
        movl -12(%ebp),%ecx

        #ako je a veci ili jednak b
        cmpl %ecx,%eax
        jge oduzmi_a_veci

        #ako je manji
        jmp oduzmi_a_manji
oduzmi_a_veci:
        #oduzimanje nizeg
        movl -4(%ebp),%eax
        movl -12(%ebp),%ecx
        subl %ecx,%eax
        #prebacivanje nizeg u r
        movl %eax,(%edx,%ebx,8)

        #oduzimanje veceg
        movl -8(%ebp),%eax
        movl -16(%ebp),%ecx
        sbbl %ecx,%eax

        #prebacivanje viseg u r
        movl %eax,4(%edx,%ebx,8)
        jmp inkrement
oduzmi_a_manji:
        movl -4(%ebp),%eax
        movl -12(%ebp),%ecx
        subl %eax,%ecx

        movl %ecx,(%edx,%ebx,8)

        movl -8(%ebp),%eax
        movl -16(%ebp),%ecx
        sbbl %eax,%ecx

        movl %ecx,4(%edx,%ebx,8)
        jmp inkrement
inkrement:
        addl $1,%ebx

        cmpl %esi,%ebx
        je kraj

        #prebacivanje vrijednosti a u stack
        movl 8(%ebp),%eax
        movl (%eax,%ebx,8),%ecx
        movl %ecx,-4(%ebp)

        addl $4,%eax
        movl (%eax,%ebx,8),%ecx
        movl %ecx,-8(%ebp)

        #prebacivanje vrijednosti b u stack
        movl 12(%ebp),%eax
        movl (%eax,%ebx,8),%ecx
        movl %ecx,-12(%ebp)

        addl $4,%eax
        movl (%eax,%ebx,8),%ecx
        movl %ecx,-16(%ebp)

        #prebacivanje visih vrijednosti u registre
        movl -8(%ebp),%eax
        movl -16(%ebp),%ecx
        jmp relacijavisi
kraj:
        popl %esi
        popl %ebx
        addl $16,%esp
        popl %ebp
        ret
